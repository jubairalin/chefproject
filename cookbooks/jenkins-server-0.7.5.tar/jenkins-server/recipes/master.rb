include_recipe 'jenkins::master'
include_recipe 'jenkins-server::user'