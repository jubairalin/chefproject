default['jenkins']['master']['version'] = '1.642-1.1' # LTS
default['jenkins']['master']['jvm_options'] = '-Xms256m -Xmx256m'
default['jenkins']['master']['listen_address'] = '127.0.0.1'
