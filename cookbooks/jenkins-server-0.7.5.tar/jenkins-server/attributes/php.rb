# Add PHP packages that are required by composer vendors
default['php']['packages'] << 'php-mbstring'
